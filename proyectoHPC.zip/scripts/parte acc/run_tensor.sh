#!/bin/bash
#SBATCH --job-name=tensorflow
#SBATCH --output=logs/%J.out
#SBATCH --error=logs/%J.err
#SBATCH -N 1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=20
#SBATCH --qos=acc_debug
#SBATCH --account=nct_321
#SBATCH --gres=gpu:1
#SBATCH --ear=on
#SBATCH --constraint=perfparanoid

module load tensorflow/2.16.1
export OMP_NUM_THREADS=18
export EARL_REPORT_LOOPS=1

# ResNet50
#srun --ear-user-db=resnet50.csv -J ResNet50 python benchmark.py --model=ResNet50 --num-iters=100
#mv resnet50.csv* ResNet50/ 2>/dev/null

#srun --ear-user-db=resnet50_mixed.csv -J ResNet50_mixed python benchmark.py --model=ResNet50 --mixed-prec --num-iters=100
#mv resnet50_mixed.csv* ResNet50/ 2>/dev/null

srun --ear-user-db=resnet50_disable.csv -J ResNet50_disable python benchmark.py --model=ResNet50 --disable-tf32 --num-iters=100
mv resnet50_disable.csv* ResNet50/ 2>/dev/null

# VGG19
#srun --ear-user-db=vgg19.csv -J VGG19 python benchmark.py --model=VGG19 --num-iters=100
#mv vgg19.csv* VGG19/ 2>/dev/null

#srun --ear-user-db=vgg19_mixed.csv -J VGG19_mixed python benchmark.py --model=VGG19 --mixed-prec --num-iters=100
#mv vgg19_mixed.csv* VGG19/ 2>/dev/null

srun --ear-user-db=vgg19_disable.csv -J VGG19_disable python benchmark.py --model=VGG19 --disable-tf32 --num-iters=100
mv vgg19_disable.csv* VGG19/ 2>/dev/null

# DenseNet121
#srun --ear-user-db=densenet121.csv -J DenseNet121 python benchmark.py --model=DenseNet121 --num-iters=100
#mv densenet121.csv* DenseNet121/ 2>/dev/null

#srun --ear-user-db=densenet121_mixed.csv -J DenseNet121_mixed python benchmark.py --model=DenseNet121 --mixed-prec --num-iters=100
#mv densenet121_mixed.csv* DenseNet121/ 2>/dev/null

srun --ear-user-db=densenet121_disable.csv -J DenseNet121_disable python benchmark.py --model=DenseNet121 --disable-tf32 --num-iters=100
mv densenet121_disable.csv* DenseNet121/ 2>/dev/null

