# -------------
# benchmark.py
# -------------
 
import argparse
import os
import numpy as np
import timeit
 
import tensorflow as tf
from tensorflow.keras import applications
from tensorflow.keras import mixed_precision
 
# Benchmark settings
parser = argparse.ArgumentParser(description='TensorFlow Synthetic Benchmark',
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
parser.add_argument('--mixed-prec', action='store_true', default=False,
                    help='Use mixed precision for training')
parser.add_argument('--disable-tf32', action='store_true', default=False,
                    help='Disable the use of TensorFloat32 for training')
 
parser.add_argument('--model', type=str, default='ResNet50',
                    help='model to benchmark')
parser.add_argument('--batch-size', type=int, default=128,
                    help='input batch size')
 
parser.add_argument('--num-warmup-batches', type=int, default=2,
                    help='number of warm-up batches that don\'t count towards benchmark')
parser.add_argument('--num-batches-per-iter', type=int, default=10,
                    help='number of batches per benchmark iteration')
parser.add_argument('--num-iters', type=int, default=10,
                    help='number of benchmark iterations')
args = parser.parse_args()
 
tf.config.threading.set_inter_op_parallelism_threads(1)
 
tf.config.threading.set_intra_op_parallelism_threads(int(os.environ['OMP_NUM_THREADS']))
 
if args.mixed_prec:
    print('Running with mixed_float16 as global policy for the precision')
    mixed_precision.set_global_policy('mixed_float16')
 
if args.disable_tf32:
    print('Disabling TF32 execution')
    tf.config.experimental.enable_tensor_float_32_execution(False)
 
# Fix seed so that it runs the same every time
tf.random.set_seed(42)
 
# Set up standard model.
model = getattr(applications, args.model)(weights=None)
opt = tf.optimizers.SGD(0.01)
if args.mixed_prec:
    print('Running with loss scaling for mixed precision')
    opt = mixed_precision.LossScaleOptimizer(opt)
 
data = tf.random.uniform([args.batch_size, 224, 224, 3])
target = tf.random.uniform([args.batch_size, 1], minval=0, maxval=999, dtype=tf.int64)
 
print('Model: %s' % args.model)
print('Batch size: %d' % args.batch_size)
 
@tf.function
def benchmark_step():
    # Record gradients with GradientTape
    with tf.GradientTape() as tape:
        probs = model(data, training=True)
        loss = tf.losses.sparse_categorical_crossentropy(target, probs)
        if args.mixed_prec:
            scaled_loss = opt.get_scaled_loss(loss)
    if args.mixed_prec:
        scaled_gradients = tape.gradient(scaled_loss, model.trainable_variables)
        gradients = opt.get_unscaled_gradients(scaled_gradients)
    else:
        gradients = tape.gradient(loss, model.trainable_variables)
    opt.apply_gradients(zip(gradients, model.trainable_variables))
 
    # Return the loss so we can inspect the effect of datatype accuracy
    return tf.math.reduce_mean(loss)
 
with tf.device('GPU'):
    # Warm-up
    print('Running warmup...')
    loss = benchmark_step()
    print(f"loss: {loss}")
 
    timeit.timeit(lambda: print(f"loss: {benchmark_step()}"),
                  number=args.num_warmup_batches)
 
    # Benchmark
    print('Running benchmark...')
    img_secs = []
    for x in range(args.num_iters):
        time = timeit.timeit(lambda: benchmark_step(),
                             number=args.num_batches_per_iter)
        img_sec = args.batch_size * args.num_batches_per_iter / time
        print('Iter #%d: %.1f img/sec' % (x, img_sec))
        img_secs.append(img_sec)
 
    # Results
    img_sec_mean = np.mean(img_secs)
    img_sec_conf = 1.96 * np.std(img_secs)
    print('Img/sec: %.1f +-%.1f' % (img_sec_mean, img_sec_conf))

